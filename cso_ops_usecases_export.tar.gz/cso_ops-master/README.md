# Project CSO - Use Cases #

## Git Repository Requirements ##

- OS: Any Linux or Mac Host we can run Docker on.

## Git Installation if you do not have a currently running Gitlab ##
##### *If you have a current Gitlab in the environment skip to Repository installation:* ##### 

- Install Docker CE 
- Follow instructions listed here for Docker install: https://docs.docker.com/install/

##### *After docker installation is completed, use the following command:* #####

- Run the following command to install a Gitlab Docker
```bash
docker run --detach \
           --hostname "10.10.11.223" \
           --name gitlab \
           --restart always \
           --volume /srv/gitlab/config:/etc/gitlab \
           --volume /srv/gitlab/logs:/tmp/gitlab/logs \
           --volume /srv/gitlab/data:/tmp/gitlab/data \
           --publish 9080:9080 --publish 3022:22 --publish 9443:9443 \
           --env GITLAB_OMNIBUS_CONFIG="external_url 'http://10.10.11.223:9080'; gitlab_rails['gitlab_shell_ssh_port']=3022;" \
           gitlab/gitlab-ce:latest
```

- ##### Cavats for above: #####

    1: "--hostname" needs to be resolvable or an IP Address    
    2: The ports listed in "--publish" need to be the same for the host and container (this is due to how nginx listens on the external ports)   
    3: The external_url should be reachable hostname or ip address (host ip or external nat if proxied and port)     
```bash
    --env GITLAB_OMNIBUS_CONFIG="external_url 'http://10.10.11.223:9080'; gitlab_rails['gitlab_shell_ssh_port']=3022;"
```


### Docker ###
 + *It will take a couple of minutes for the docker container to come up*
    
Use the following command to verify that the docker is running and healthy:

```bash
root@DC76-cso-host:~# docker ps
CONTAINER ID        IMAGE                     COMMAND               CREATED             STATUS                 PORTS                                                                                             NAMES
fcc5e2aa3336        cso-ui                    "python3 ./main.py"   5 hours ago         Up 5 hours             0.0.0.0:8670->8670/tcp                                                                            cso-ui
542c6d85bfce        gitlab/gitlab-ce:latest   "/assets/wrapper"     8 hours ago         Up 8 hours (healthy)   22/tcp, 80/tcp, 0.0.0.0:3022->3022/tcp, 0.0.0.0:9080->9080/tcp, 443/tcp, 0.0.0.0:9443->9443/tcp   gitlab
```   
- Access Landing page with:
  + URL: http://\<IP>:\<PORT>
    * Set the root password

![Root Password](images/20190000.png)

##### Login to git with user:root and password:< recently set password >: #####

![Login to Gitlab](images/20190001.png)

##### Select create a group: ######
![Select a group](images/20190002.png)

##### Create a group called cso_ops and make it public: ######
![Create cso_ops group](images/20190003.png)

##### Select new Project: ######
![Select a project](images/20190004.png)

##### Select Import Project: ######
![Import a project](images/20190005.png)

##### Select from Gitlab Export: ######
![Load exported file](images/20190006.png)
    
##### Fill in Project name with useCases and ensure cso_ops is selected, choose the usecase export file and click import project : ######
![Set the repo name](images/20190007.png)


##### Copy the SSH key (cso-ui.pub) from the ssh folder: ######
![Add the SSH key](images/20190009.png)

##### The SSH key (cso-ui.pub) can be found in this repo in the ssh folder. #####
##### Select "add an SSH Key" (this is also under Administrator > Settings > SSH keys: ######
![Add the SSH key](images/20190008.png)

##### Paste the key into the window and Select "Add key" (this is also under Administrator > Settings > SSH keys: ######
![Add the SSH key](images/20190010.png)
