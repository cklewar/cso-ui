Use the following files to run Threat Visualization demo

Setup. 

Add IDP license to device and push latest signature file from CSO Admin view

Add additional libraries to Python
which python
apt-get install scapy python-dateutil


Command to run demo.
Run this command
# cd /root/UTM
# UTM# python run.py GWR.VF-ES_CPE1.retail 172.16.75.176 2 demo_idp.log


Where GWR.VF-ES_CPE1.retail is sitename.tenant_name
 172.16.75.176 is SLB VM
2 - is number of messages per second
demo_idp.log is input log file

or modify run.sh and change for your system

root@dc71-cso:~/UTM# more run.sh
/usr/bin/python /root/UTM/run.py SRX300-CPE2_CPE1.retail 172.16.71.176 1 /root/UTM/demo_idp.log

chmod +x run.sh

