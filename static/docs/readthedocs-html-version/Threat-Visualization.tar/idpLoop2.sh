#!/bin/bash
x="0"
while [ $x -lt 2 ] 
   do
   bash -c "python ./run.py Retail-SRX300_CPE1.retail 172.16.79.176 1 ./IDPSite1.log"
   bash -c "python ./run.py GWR.Retail-NFX1_CPE1.retail 172.16.79.176 1 ./IDPSite2.log"
   bash -c "python ./run.py GWR.Retail-NFX2_CPE1.retail 172.16.79.176 1 ./IDPSite3.log"
   x=$[$x+1]
   done

