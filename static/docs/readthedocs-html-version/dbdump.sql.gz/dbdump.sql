-- MySQL dump 10.13  Distrib 5.5.59, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: guacamole_db
-- ------------------------------------------------------
-- Server version	5.5.59-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `guacamole_db`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `guacamole_db` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `guacamole_db`;

--
-- Table structure for table `guacamole_connection`
--

DROP TABLE IF EXISTS `guacamole_connection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_connection` (
  `connection_id` int(11) NOT NULL AUTO_INCREMENT,
  `connection_name` varchar(128) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `protocol` varchar(32) NOT NULL,
  `proxy_port` int(11) DEFAULT NULL,
  `proxy_hostname` varchar(512) DEFAULT NULL,
  `proxy_encryption_method` enum('NONE','SSL') DEFAULT NULL,
  `max_connections` int(11) DEFAULT NULL,
  `max_connections_per_user` int(11) DEFAULT NULL,
  `connection_weight` int(11) DEFAULT NULL,
  `failover_only` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`connection_id`),
  UNIQUE KEY `connection_name_parent` (`connection_name`,`parent_id`),
  KEY `guacamole_connection_ibfk_1` (`parent_id`),
  CONSTRAINT `guacamole_connection_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `guacamole_connection_group` (`connection_group_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_connection`
--

LOCK TABLES `guacamole_connection` WRITE;
/*!40000 ALTER TABLE `guacamole_connection` DISABLE KEYS */;
INSERT INTO `guacamole_connection` VALUES (1,'CSO-Host',1,'ssh',NULL,NULL,NULL,2,2,NULL,0),(2,'desktop2',2,'vnc',NULL,NULL,NULL,2,2,NULL,0),(3,'desktop1',2,'vnc',NULL,NULL,NULL,2,2,NULL,0),(4,'desktop3',2,'vnc',NULL,NULL,NULL,2,2,NULL,0),(5,'desktop4',2,'vnc',NULL,NULL,NULL,2,2,NULL,0),(6,'Raspberry-Pi',1,'ssh',NULL,NULL,NULL,2,2,NULL,0),(7,'regionalmsvm',4,'ssh',NULL,NULL,NULL,2,2,NULL,0),(8,'Contrail-Host',1,'ssh',NULL,NULL,NULL,2,2,NULL,0),(9,'MX80-1',3,'ssh',NULL,NULL,NULL,2,2,NULL,0),(10,'SRX345-1',3,'ssh',NULL,NULL,NULL,2,2,NULL,0),(11,'SRX1500-1',3,'ssh',NULL,NULL,NULL,2,2,NULL,0),(12,'QFX5100-1',3,'ssh',NULL,NULL,NULL,2,2,NULL,0),(13,'NFX250-1 provisioned',3,'ssh',NULL,NULL,NULL,2,2,NULL,0),(14,'NFX250-1 default',3,'ssh',NULL,NULL,NULL,2,2,NULL,0),(15,'centralmsvm',4,'ssh',NULL,NULL,NULL,2,2,NULL,0),(16,'centralinfra',4,'ssh',NULL,NULL,NULL,2,2,NULL,0),(17,'regionalinfra',4,'ssh',NULL,NULL,NULL,2,2,NULL,0);
/*!40000 ALTER TABLE `guacamole_connection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guacamole_connection_group`
--

DROP TABLE IF EXISTS `guacamole_connection_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_connection_group` (
  `connection_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `connection_group_name` varchar(128) NOT NULL,
  `type` enum('ORGANIZATIONAL','BALANCING') NOT NULL DEFAULT 'ORGANIZATIONAL',
  `max_connections` int(11) DEFAULT NULL,
  `max_connections_per_user` int(11) DEFAULT NULL,
  `enable_session_affinity` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`connection_group_id`),
  UNIQUE KEY `connection_group_name_parent` (`connection_group_name`,`parent_id`),
  KEY `guacamole_connection_group_ibfk_1` (`parent_id`),
  CONSTRAINT `guacamole_connection_group_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `guacamole_connection_group` (`connection_group_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_connection_group`
--

LOCK TABLES `guacamole_connection_group` WRITE;
/*!40000 ALTER TABLE `guacamole_connection_group` DISABLE KEYS */;
INSERT INTO `guacamole_connection_group` VALUES (1,NULL,'Hosts','ORGANIZATIONAL',NULL,NULL,0),(2,NULL,'DesktopVMs','ORGANIZATIONAL',NULL,NULL,0),(3,NULL,'Devices','ORGANIZATIONAL',NULL,NULL,0),(4,NULL,'CSO-VMs','ORGANIZATIONAL',NULL,NULL,0);
/*!40000 ALTER TABLE `guacamole_connection_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guacamole_connection_group_permission`
--

DROP TABLE IF EXISTS `guacamole_connection_group_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_connection_group_permission` (
  `user_id` int(11) NOT NULL,
  `connection_group_id` int(11) NOT NULL,
  `permission` enum('READ','UPDATE','DELETE','ADMINISTER') NOT NULL,
  PRIMARY KEY (`user_id`,`connection_group_id`,`permission`),
  KEY `guacamole_connection_group_permission_ibfk_1` (`connection_group_id`),
  CONSTRAINT `guacamole_connection_group_permission_ibfk_1` FOREIGN KEY (`connection_group_id`) REFERENCES `guacamole_connection_group` (`connection_group_id`) ON DELETE CASCADE,
  CONSTRAINT `guacamole_connection_group_permission_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `guacamole_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_connection_group_permission`
--

LOCK TABLES `guacamole_connection_group_permission` WRITE;
/*!40000 ALTER TABLE `guacamole_connection_group_permission` DISABLE KEYS */;
INSERT INTO `guacamole_connection_group_permission` VALUES (2,1,'READ'),(2,1,'UPDATE'),(2,1,'DELETE'),(2,1,'ADMINISTER'),(2,2,'READ'),(2,2,'UPDATE'),(2,2,'DELETE'),(2,2,'ADMINISTER'),(2,3,'READ'),(2,3,'UPDATE'),(2,3,'DELETE'),(2,3,'ADMINISTER'),(2,4,'READ'),(2,4,'UPDATE'),(2,4,'DELETE'),(2,4,'ADMINISTER');
/*!40000 ALTER TABLE `guacamole_connection_group_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guacamole_connection_history`
--

DROP TABLE IF EXISTS `guacamole_connection_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_connection_history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(128) NOT NULL,
  `remote_host` varchar(256) DEFAULT NULL,
  `connection_id` int(11) DEFAULT NULL,
  `connection_name` varchar(128) NOT NULL,
  `sharing_profile_id` int(11) DEFAULT NULL,
  `sharing_profile_name` varchar(128) DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`history_id`),
  KEY `user_id` (`user_id`),
  KEY `connection_id` (`connection_id`),
  KEY `sharing_profile_id` (`sharing_profile_id`),
  KEY `start_date` (`start_date`),
  KEY `end_date` (`end_date`),
  KEY `connection_start_date` (`connection_id`,`start_date`),
  CONSTRAINT `guacamole_connection_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `guacamole_user` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `guacamole_connection_history_ibfk_2` FOREIGN KEY (`connection_id`) REFERENCES `guacamole_connection` (`connection_id`) ON DELETE SET NULL,
  CONSTRAINT `guacamole_connection_history_ibfk_3` FOREIGN KEY (`sharing_profile_id`) REFERENCES `guacamole_sharing_profile` (`sharing_profile_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_connection_history`
--

LOCK TABLES `guacamole_connection_history` WRITE;
/*!40000 ALTER TABLE `guacamole_connection_history` DISABLE KEYS */;
INSERT INTO `guacamole_connection_history` VALUES (1,2,'juniper','172.29.66.94',1,'CSO-Host-SSH',NULL,NULL,'2018-04-12 17:03:37','2018-04-12 17:05:24'),(2,2,'juniper','172.29.66.94',2,'desktop2',NULL,NULL,'2018-04-12 17:06:57','2018-04-12 17:07:22'),(3,2,'juniper','172.29.66.94',2,'desktop2',NULL,NULL,'2018-04-12 17:09:16','2018-04-12 17:10:15'),(4,2,'juniper','172.29.66.94',1,'CSO-Host-SSH',NULL,NULL,'2018-04-12 17:25:05','2018-04-12 17:26:02'),(5,2,'juniper','172.29.66.94',2,'desktop2',NULL,NULL,'2018-04-12 17:25:52','2018-04-12 17:26:02'),(6,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:10:06','2018-04-12 21:18:02'),(7,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:18:17','2018-04-12 21:18:17'),(8,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:18:32','2018-04-12 21:18:32'),(9,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:18:48','2018-04-12 21:18:48'),(10,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:19:03','2018-04-12 21:19:03'),(11,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:19:18','2018-04-12 21:19:18'),(12,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:19:34','2018-04-12 21:19:34'),(13,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:19:49','2018-04-12 21:19:49'),(14,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:20:04','2018-04-12 21:20:04'),(15,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:20:20','2018-04-12 21:20:20'),(16,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:20:35','2018-04-12 21:20:35'),(17,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:20:50','2018-04-12 21:20:50'),(18,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:21:05','2018-04-12 21:21:06'),(19,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:21:21','2018-04-12 21:21:21'),(20,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:21:36','2018-04-12 21:21:36'),(21,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:21:51','2018-04-12 21:21:51'),(22,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:22:07','2018-04-12 21:22:07'),(23,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:22:22','2018-04-12 21:22:22'),(24,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:22:37','2018-04-12 21:22:37'),(25,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:22:52','2018-04-12 21:22:53'),(26,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:23:08','2018-04-12 21:23:08'),(27,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:23:23','2018-04-12 21:23:23'),(28,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:23:38','2018-04-12 21:23:38'),(29,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:23:54','2018-04-12 21:23:54'),(30,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:24:09','2018-04-12 21:24:09'),(31,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:24:24','2018-04-12 21:24:24'),(32,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:24:40','2018-04-12 21:24:40'),(33,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:24:43','2018-04-12 21:24:43'),(34,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:24:47','2018-04-12 21:24:47'),(35,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:24:54','2018-04-12 21:24:54'),(36,2,'juniper','172.29.66.132',2,'desktop2',NULL,NULL,'2018-04-12 21:24:56','2018-04-12 21:24:56'),(37,2,'juniper','172.29.66.132',1,'CSO-Host-SSH',NULL,NULL,'2018-04-12 21:02:57','2018-04-12 21:40:45'),(38,2,'juniper','172.29.66.132',1,'CSO-Host-SSH',NULL,NULL,'2018-04-12 21:24:59','2018-04-12 21:40:45'),(39,2,'juniper','172.29.66.94',6,'Raspberry-Pi',NULL,NULL,'2018-04-12 21:50:10','2018-04-12 21:50:49'),(40,2,'juniper','172.29.66.94',2,'desktop2',NULL,NULL,'2018-04-12 21:51:05','2018-04-12 21:52:19'),(41,2,'juniper','172.29.66.94',7,'regionalmsvm',NULL,NULL,'2018-04-12 21:54:08','2018-04-12 21:54:11'),(42,2,'juniper','172.29.66.94',9,'MX80-1',NULL,NULL,'2018-04-12 21:55:11','2018-04-12 21:55:31'),(43,2,'juniper','172.29.66.94',7,'regionalmsvm',NULL,NULL,'2018-04-12 22:18:28','2018-04-12 22:19:29'),(44,2,'juniper','172.29.66.132',5,'desktop4',NULL,NULL,'2018-04-13 07:51:42','2018-04-13 08:32:30'),(45,2,'juniper','172.29.66.132',3,'desktop1',NULL,NULL,'2018-04-13 07:38:52','2018-04-13 08:32:32'),(46,2,'juniper','172.29.66.132',15,'centralmsvm',NULL,NULL,'2018-04-13 07:54:41','2018-04-13 09:33:16'),(47,2,'juniper','172.29.66.132',1,'CSO-Host',NULL,NULL,'2018-04-13 07:56:52','2018-04-13 09:33:18'),(48,2,'juniper','172.29.66.132',8,'Contrail-Host',NULL,NULL,'2018-04-13 07:56:30','2018-04-13 09:50:22'),(55,2,'juniper','172.29.66.94',9,'MX80-1',NULL,NULL,'2018-04-17 07:52:00','2018-04-17 07:52:10'),(56,2,'juniper','172.29.66.94',9,'MX80-1',NULL,NULL,'2018-04-17 07:59:13','2018-04-17 07:59:37');
/*!40000 ALTER TABLE `guacamole_connection_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guacamole_connection_parameter`
--

DROP TABLE IF EXISTS `guacamole_connection_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_connection_parameter` (
  `connection_id` int(11) NOT NULL,
  `parameter_name` varchar(128) NOT NULL,
  `parameter_value` varchar(4096) NOT NULL,
  PRIMARY KEY (`connection_id`,`parameter_name`),
  CONSTRAINT `guacamole_connection_parameter_ibfk_1` FOREIGN KEY (`connection_id`) REFERENCES `guacamole_connection` (`connection_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_connection_parameter`
--

LOCK TABLES `guacamole_connection_parameter` WRITE;
/*!40000 ALTER TABLE `guacamole_connection_parameter` DISABLE KEYS */;
INSERT INTO `guacamole_connection_parameter` VALUES (1,'color-scheme','green-black'),(1,'enable-sftp','true'),(1,'hostname','192.168.10.10'),(1,'password','juniper123'),(1,'port','22'),(1,'username','root'),(2,'clipboard-encoding','UTF-8'),(2,'hostname','192.168.10.10'),(2,'port','5992'),(3,'clipboard-encoding','UTF-8'),(3,'hostname','192.168.10.10'),(3,'port','5991'),(4,'clipboard-encoding','UTF-8'),(4,'hostname','192.168.10.10'),(4,'port','5993'),(5,'clipboard-encoding','UTF-8'),(5,'hostname','192.168.10.10'),(5,'port','5994'),(6,'color-scheme','green-black'),(6,'enable-sftp','true'),(6,'hostname','192.168.10.2'),(6,'password','Lab58fgr#-1'),(6,'port','22'),(6,'username','root'),(7,'color-scheme','green-black'),(7,'enable-sftp','true'),(7,'hostname','192.168.10.45'),(7,'password','passw0rd'),(7,'port','22'),(7,'username','root'),(8,'color-scheme','green-black'),(8,'enable-sftp','true'),(8,'hostname','192.168.10.15'),(8,'password','juniper123'),(8,'port','22'),(8,'username','root'),(9,'color-scheme','green-black'),(9,'enable-sftp','true'),(9,'hostname','192.168.10.21'),(9,'password','juniper123'),(9,'port','22'),(9,'username','root'),(10,'color-scheme','green-black'),(10,'enable-sftp','true'),(10,'hostname','192.168.170.2'),(10,'password','Embe1mpls'),(10,'port','22'),(10,'username','root'),(11,'color-scheme','green-black'),(11,'enable-sftp','true'),(11,'hostname','192.168.190.254'),(11,'password','Embe1mpls'),(11,'port','22'),(11,'username','root'),(12,'color-scheme','green-black'),(12,'enable-sftp','true'),(12,'hostname','192.168.10.20'),(12,'password','juniper123'),(12,'port','22'),(12,'username','root'),(13,'color-scheme','green-black'),(13,'enable-sftp','true'),(13,'hostname','192.168.170.24'),(13,'password','Embe1mpls'),(13,'port','22'),(13,'username','root'),(14,'color-scheme','green-black'),(14,'enable-sftp','true'),(14,'hostname','192.168.170.24'),(14,'password','juniper123'),(14,'port','22'),(14,'username','root'),(15,'color-scheme','green-black'),(15,'enable-sftp','true'),(15,'hostname','192.168.10.42'),(15,'password','passw0rd'),(15,'port','22'),(15,'username','root'),(16,'color-scheme','green-black'),(16,'enable-sftp','true'),(16,'hostname','192.168.10.41'),(16,'password','passw0rd'),(16,'port','22'),(16,'username','root'),(17,'color-scheme','green-black'),(17,'enable-sftp','true'),(17,'hostname','192.168.10.44'),(17,'password','passw0rd'),(17,'port','22'),(17,'username','root');
/*!40000 ALTER TABLE `guacamole_connection_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guacamole_connection_permission`
--

DROP TABLE IF EXISTS `guacamole_connection_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_connection_permission` (
  `user_id` int(11) NOT NULL,
  `connection_id` int(11) NOT NULL,
  `permission` enum('READ','UPDATE','DELETE','ADMINISTER') NOT NULL,
  PRIMARY KEY (`user_id`,`connection_id`,`permission`),
  KEY `guacamole_connection_permission_ibfk_1` (`connection_id`),
  CONSTRAINT `guacamole_connection_permission_ibfk_1` FOREIGN KEY (`connection_id`) REFERENCES `guacamole_connection` (`connection_id`) ON DELETE CASCADE,
  CONSTRAINT `guacamole_connection_permission_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `guacamole_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_connection_permission`
--

LOCK TABLES `guacamole_connection_permission` WRITE;
/*!40000 ALTER TABLE `guacamole_connection_permission` DISABLE KEYS */;
INSERT INTO `guacamole_connection_permission` VALUES (2,1,'READ'),(2,1,'UPDATE'),(2,1,'DELETE'),(2,1,'ADMINISTER'),(2,2,'READ'),(2,2,'UPDATE'),(2,2,'DELETE'),(2,2,'ADMINISTER'),(2,3,'READ'),(2,3,'UPDATE'),(2,3,'DELETE'),(2,3,'ADMINISTER'),(2,4,'READ'),(2,4,'UPDATE'),(2,4,'DELETE'),(2,4,'ADMINISTER'),(2,5,'READ'),(2,5,'UPDATE'),(2,5,'DELETE'),(2,5,'ADMINISTER'),(2,6,'READ'),(2,6,'UPDATE'),(2,6,'DELETE'),(2,6,'ADMINISTER'),(2,7,'READ'),(2,7,'UPDATE'),(2,7,'DELETE'),(2,7,'ADMINISTER'),(2,8,'READ'),(2,8,'UPDATE'),(2,8,'DELETE'),(2,8,'ADMINISTER'),(2,9,'READ'),(2,9,'UPDATE'),(2,9,'DELETE'),(2,9,'ADMINISTER'),(2,10,'READ'),(2,10,'UPDATE'),(2,10,'DELETE'),(2,10,'ADMINISTER'),(2,11,'READ'),(2,11,'UPDATE'),(2,11,'DELETE'),(2,11,'ADMINISTER'),(2,12,'READ'),(2,12,'UPDATE'),(2,12,'DELETE'),(2,12,'ADMINISTER'),(2,13,'READ'),(2,13,'UPDATE'),(2,13,'DELETE'),(2,13,'ADMINISTER'),(2,14,'READ'),(2,14,'UPDATE'),(2,14,'DELETE'),(2,14,'ADMINISTER'),(2,15,'READ'),(2,15,'UPDATE'),(2,15,'DELETE'),(2,15,'ADMINISTER'),(2,16,'READ'),(2,16,'UPDATE'),(2,16,'DELETE'),(2,16,'ADMINISTER'),(2,17,'READ'),(2,17,'UPDATE'),(2,17,'DELETE'),(2,17,'ADMINISTER');
/*!40000 ALTER TABLE `guacamole_connection_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guacamole_sharing_profile`
--

DROP TABLE IF EXISTS `guacamole_sharing_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_sharing_profile` (
  `sharing_profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `sharing_profile_name` varchar(128) NOT NULL,
  `primary_connection_id` int(11) NOT NULL,
  PRIMARY KEY (`sharing_profile_id`),
  UNIQUE KEY `sharing_profile_name_primary` (`sharing_profile_name`,`primary_connection_id`),
  KEY `guacamole_sharing_profile_ibfk_1` (`primary_connection_id`),
  CONSTRAINT `guacamole_sharing_profile_ibfk_1` FOREIGN KEY (`primary_connection_id`) REFERENCES `guacamole_connection` (`connection_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_sharing_profile`
--

LOCK TABLES `guacamole_sharing_profile` WRITE;
/*!40000 ALTER TABLE `guacamole_sharing_profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `guacamole_sharing_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guacamole_sharing_profile_parameter`
--

DROP TABLE IF EXISTS `guacamole_sharing_profile_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_sharing_profile_parameter` (
  `sharing_profile_id` int(11) NOT NULL,
  `parameter_name` varchar(128) NOT NULL,
  `parameter_value` varchar(4096) NOT NULL,
  PRIMARY KEY (`sharing_profile_id`,`parameter_name`),
  CONSTRAINT `guacamole_sharing_profile_parameter_ibfk_1` FOREIGN KEY (`sharing_profile_id`) REFERENCES `guacamole_sharing_profile` (`sharing_profile_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_sharing_profile_parameter`
--

LOCK TABLES `guacamole_sharing_profile_parameter` WRITE;
/*!40000 ALTER TABLE `guacamole_sharing_profile_parameter` DISABLE KEYS */;
/*!40000 ALTER TABLE `guacamole_sharing_profile_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guacamole_sharing_profile_permission`
--

DROP TABLE IF EXISTS `guacamole_sharing_profile_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_sharing_profile_permission` (
  `user_id` int(11) NOT NULL,
  `sharing_profile_id` int(11) NOT NULL,
  `permission` enum('READ','UPDATE','DELETE','ADMINISTER') NOT NULL,
  PRIMARY KEY (`user_id`,`sharing_profile_id`,`permission`),
  KEY `guacamole_sharing_profile_permission_ibfk_1` (`sharing_profile_id`),
  CONSTRAINT `guacamole_sharing_profile_permission_ibfk_1` FOREIGN KEY (`sharing_profile_id`) REFERENCES `guacamole_sharing_profile` (`sharing_profile_id`) ON DELETE CASCADE,
  CONSTRAINT `guacamole_sharing_profile_permission_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `guacamole_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_sharing_profile_permission`
--

LOCK TABLES `guacamole_sharing_profile_permission` WRITE;
/*!40000 ALTER TABLE `guacamole_sharing_profile_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `guacamole_sharing_profile_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guacamole_system_permission`
--

DROP TABLE IF EXISTS `guacamole_system_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_system_permission` (
  `user_id` int(11) NOT NULL,
  `permission` enum('CREATE_CONNECTION','CREATE_CONNECTION_GROUP','CREATE_SHARING_PROFILE','CREATE_USER','ADMINISTER') NOT NULL,
  PRIMARY KEY (`user_id`,`permission`),
  CONSTRAINT `guacamole_system_permission_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `guacamole_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_system_permission`
--

LOCK TABLES `guacamole_system_permission` WRITE;
/*!40000 ALTER TABLE `guacamole_system_permission` DISABLE KEYS */;
INSERT INTO `guacamole_system_permission` VALUES (1,'CREATE_CONNECTION'),(1,'CREATE_CONNECTION_GROUP'),(1,'CREATE_SHARING_PROFILE'),(1,'CREATE_USER'),(1,'ADMINISTER'),(2,'CREATE_CONNECTION'),(2,'CREATE_CONNECTION_GROUP'),(2,'CREATE_SHARING_PROFILE'),(2,'CREATE_USER'),(2,'ADMINISTER');
/*!40000 ALTER TABLE `guacamole_system_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guacamole_user`
--

DROP TABLE IF EXISTS `guacamole_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `password_hash` binary(32) NOT NULL,
  `password_salt` binary(32) DEFAULT NULL,
  `password_date` datetime NOT NULL,
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `expired` tinyint(1) NOT NULL DEFAULT '0',
  `access_window_start` time DEFAULT NULL,
  `access_window_end` time DEFAULT NULL,
  `valid_from` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `timezone` varchar(64) DEFAULT NULL,
  `full_name` varchar(256) DEFAULT NULL,
  `email_address` varchar(256) DEFAULT NULL,
  `organization` varchar(256) DEFAULT NULL,
  `organizational_role` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_user`
--

LOCK TABLES `guacamole_user` WRITE;
/*!40000 ALTER TABLE `guacamole_user` DISABLE KEYS */;
INSERT INTO `guacamole_user` VALUES (1,'guacadmin','�E�}IN;�$���u�Ul��,-}�c;�J)�A`','�$���+%(���zy�B��`d�iųw��\"d','2018-04-12 17:00:00',0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'juniper','��yL��k(��r�;�D(�xO����M��','��s�(\r\"]�\\�@�/�4KE\'3�\\�t1K��x','2018-04-12 17:01:54',0,0,NULL,NULL,NULL,NULL,NULL,'juniper',NULL,NULL,NULL);
/*!40000 ALTER TABLE `guacamole_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guacamole_user_history`
--

DROP TABLE IF EXISTS `guacamole_user_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_user_history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(128) NOT NULL,
  `remote_host` varchar(256) DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`history_id`),
  KEY `user_id` (`user_id`),
  KEY `start_date` (`start_date`),
  KEY `end_date` (`end_date`),
  KEY `user_start_date` (`user_id`,`start_date`),
  CONSTRAINT `guacamole_user_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `guacamole_user` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_user_history`
--

LOCK TABLES `guacamole_user_history` WRITE;
/*!40000 ALTER TABLE `guacamole_user_history` DISABLE KEYS */;
INSERT INTO `guacamole_user_history` VALUES (1,1,'guacadmin','172.29.66.94','2018-04-12 17:01:08','2018-04-12 17:02:01'),(2,2,'juniper','172.29.66.94','2018-04-12 17:02:09','2018-04-12 17:06:41'),(3,2,'juniper','172.29.66.94','2018-04-12 17:06:53','2018-04-12 18:07:03'),(4,2,'juniper','172.29.66.94','2018-04-12 17:08:38','2018-04-12 18:26:03'),(5,2,'juniper','172.29.66.132','2018-04-12 21:02:46','2018-04-12 22:41:03'),(6,2,'juniper','172.29.66.94','2018-04-12 21:40:28','2018-04-12 21:54:16'),(7,2,'juniper','172.29.66.94','2018-04-12 21:54:34','2018-04-12 23:08:03'),(8,2,'juniper','172.29.66.94','2018-04-12 21:55:04','2018-04-12 23:18:03'),(9,2,'juniper','172.29.66.94','2018-04-12 22:18:15','2018-04-12 22:19:32'),(10,2,'juniper','172.29.66.132','2018-04-13 07:38:44','2018-04-13 10:34:03'),(11,2,'juniper','172.29.66.94','2018-04-15 14:12:36','2018-04-15 14:13:45'),(12,2,'juniper','172.29.66.94','2018-04-15 14:14:06','2018-04-15 15:14:17'),(13,2,'juniper','172.29.66.94','2018-04-15 14:14:20','2018-04-15 14:14:30'),(14,2,'juniper','172.29.66.94','2018-04-17 07:51:51',NULL),(15,2,'juniper','172.29.66.94','2018-04-17 07:56:00',NULL),(16,2,'juniper','172.29.66.94','2018-04-17 07:59:08',NULL);
/*!40000 ALTER TABLE `guacamole_user_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guacamole_user_password_history`
--

DROP TABLE IF EXISTS `guacamole_user_password_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_user_password_history` (
  `password_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `password_hash` binary(32) NOT NULL,
  `password_salt` binary(32) DEFAULT NULL,
  `password_date` datetime NOT NULL,
  PRIMARY KEY (`password_history_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `guacamole_user_password_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `guacamole_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_user_password_history`
--

LOCK TABLES `guacamole_user_password_history` WRITE;
/*!40000 ALTER TABLE `guacamole_user_password_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `guacamole_user_password_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guacamole_user_permission`
--

DROP TABLE IF EXISTS `guacamole_user_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guacamole_user_permission` (
  `user_id` int(11) NOT NULL,
  `affected_user_id` int(11) NOT NULL,
  `permission` enum('READ','UPDATE','DELETE','ADMINISTER') NOT NULL,
  PRIMARY KEY (`user_id`,`affected_user_id`,`permission`),
  KEY `guacamole_user_permission_ibfk_1` (`affected_user_id`),
  CONSTRAINT `guacamole_user_permission_ibfk_1` FOREIGN KEY (`affected_user_id`) REFERENCES `guacamole_user` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `guacamole_user_permission_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `guacamole_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guacamole_user_permission`
--

LOCK TABLES `guacamole_user_permission` WRITE;
/*!40000 ALTER TABLE `guacamole_user_permission` DISABLE KEYS */;
INSERT INTO `guacamole_user_permission` VALUES (1,1,'READ'),(1,1,'UPDATE'),(1,1,'ADMINISTER'),(1,2,'READ'),(1,2,'UPDATE'),(1,2,'DELETE'),(1,2,'ADMINISTER'),(2,2,'READ'),(2,2,'UPDATE');
/*!40000 ALTER TABLE `guacamole_user_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-17  8:06:41
