/usr/bin/python /root/UTM/run.py GWR.SunnyNFX4_CPE1.tenant1 172.16.75.176 1 /root/UTM/demo_idp.log
