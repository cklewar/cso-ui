#!/usr/bin/python
import sys, getopt
from scapy.all import *
from scapy.layers.inet import IP, UDP
from time import sleep
from dateutil.relativedelta import relativedelta
from datetime import datetime

def main(argv):
    cmdargs = str(sys.argv)
    total = len(sys.argv)
    if total != 5 :
        print "Total no of arguemnts are not passed properly, given %d expected 5" % total
        print 'Usage is : send-syslog.py <Source_Hostname> <olsc_ip> <message_per-sec> <file>'
    else :
        source_ip = str(sys.argv[1])
        oslc_ip = str(sys.argv[2])
        messages_per_sec = int(sys.argv[3])
        syslog_file = str(sys.argv[4])
        verbose = True
        print "Device Hostnme : %s " % source_ip
        print "OSLC IP is : %s " % oslc_ip
        print "messages per sec is : %s " % messages_per_sec
        print "syslog file is : %s " % syslog_file
        #send syslog
        time_delay = 0
        delay = 1.0 / messages_per_sec
        with open(syslog_file) as syslog_file:
            content = syslog_file.readlines()
            for line in content:
                if line.startswith("sleep"):
                    time_ = line
                    time_in_sec = time_[6:]
                    time.sleep(int(time_in_sec))
                    time_delay = time_delay + int(time_in_sec)

                if line.startswith("<14>1"):
                    time_delay = time_delay + 1
                    # Replace the Time in the existing Log to the current time and deplay as per the deplay provided in the File or delay woth 1 sec per each log.
                    current_time = datetime.utcnow()
                    minutes = time_delay // 60
                    seconds = time_delay - (minutes * 60)
                    if minutes != 0:
                        current_time = current_time + relativedelta(minutes=+int(minutes))
                    if seconds != 0:
                        current_time = current_time + relativedelta(seconds=+int(seconds))

                    c_time = str(current_time)
                    c_time = c_time.replace(" ", "T")
                    c_time = c_time[:-3]
                    c_time = c_time + "Z"
                    position = line.find('RT_FLOW')
                    if position == -1 :
                        position = line.find('RT_IDP')
                    if position == -1:
                        position = line.find('RT_UTM')
                    line = line[position:]
                    line = '<14>1 ' + c_time + " " + source_ip +" " + line
                    print "Syslog is : ", line

                    i = 0;
                    total_messages = 0
                    while (i < 1):
                        syslog = IP( dst=oslc_ip) / UDP(sport=514, dport=514) / Raw(load=line)
                        send(syslog, verbose=True)
                        total_messages += 1

                        if verbose:
                            syslog.show()
                        i += 1
                        time.sleep(delay)
            print("Total syslogs sent : %d" % total_messages)


if __name__ == "__main__":
   main(sys.argv[1:])

